import 'package:get/get.dart';

import '../modules/home/CoustomWebView/bindings/coustom_web_view.binding.dart';
import '../modules/home/CoustomWebView/views/coustom_web_view.view.dart';
import '../modules/home/bindings/home_binding.dart';
import '../modules/home/views/home_view.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const INITIAL = Routes.HOME;

  static final routes = [
    GetPage(
      name: _Paths.HOME,
      page: () => HomeView(),
      binding: HomeBinding(),
      children: [
        GetPage(
          name: _Paths.COUSTOM_WEB_VIEW,
          page: () => const CoustomWebViewView(),
          binding: CoustomWebViewBinding(),
        ),
      ],
    ),
  ];
}
