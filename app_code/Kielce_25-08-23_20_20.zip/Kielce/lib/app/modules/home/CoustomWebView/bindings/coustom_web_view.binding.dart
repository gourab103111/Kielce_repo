import 'package:get/get.dart';

import '../controllers/coustom_web_view.controller.dart';

class CoustomWebViewBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<CoustomWebViewController>(
      () => CoustomWebViewController(),
    );
  }
}
