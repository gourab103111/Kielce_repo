import 'package:get/get.dart';
import 'package:just_audio/just_audio.dart';

import '../views/player_view.view.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';

class HomeController extends GetxController {
  //TODO: Implement HomeController

  final count = 0.obs;
  final updateview = "".obs;
  final websiteUrl = "".obs;
  final isPlay = false.obs;
  final isLoaded = false.obs;

  var presentViewStr = "Test ".obs;

  final mainMediaUrl =
      "https://stream4.radioem.pl/stream/?fbclid=IwAR2SfKgTqJELjQ0bBzZif_bET5rhp20MkBUTxAi-ZZ137L17aAaTj_6UDws"
          .obs;

  AudioPlayer player = AudioPlayer(
    userAgent: 'myradioapp/1.0 (Linux;Android 11) https://myradioapp.com',
  );
  @override
  void onInit() async {
    super.onInit();

    this.isLoaded.value = false;
  }

  @override
  void onReady() async {
    super.onReady();
    FlutterNativeSplash.remove();

    this.isLoaded.value = true;

    await player.setUrl("http://emkielce.pl:8000/;stream/1", preload: true);

    await player.load();

    this.isLoaded.value = false;
  }

  @override
  void onClose() {
    super.onClose();
  }

  void setPresentView(dynamic viewitem) {}

  void startPlay() async {
    if (!this.isLoaded.value) {
      if (!player.playing) {
        isPlay.value = true;

        await player.play();
      } else {
        isPlay.value = false;
        await player.pause();
      }
    }
  }
}
