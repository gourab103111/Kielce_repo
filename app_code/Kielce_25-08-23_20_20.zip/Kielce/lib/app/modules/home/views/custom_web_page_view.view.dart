import 'package:flutter/material.dart';

import 'package:get/get.dart';

class CustomWebPageViewView extends GetView {
  const CustomWebPageViewView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      body: const Center(
        child: Text(
          'This is Webview',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
