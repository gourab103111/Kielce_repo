import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../../routes/app_pages.dart';

class ListsItems extends StatelessWidget {
  final String title;
  final String website_url;
  ListsItems(this.title, this.website_url, {super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: context.height * 0.060,
      child: ListTile(
        title: Center(
          child: Text(this.title,
              style: TextStyle(
                color: Color(0xffffffff),
                fontSize: 24.sp,
              )),
        ),
        onTap: () {
          Navigator.pop(context);
          Get.toNamed(Routes.COUSTOM_WEB_VIEW,
              arguments: {"web_url": this.website_url});
        },
      ),
    );
  }
}
