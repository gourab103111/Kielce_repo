import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:get/get.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../controllers/home_controller.dart';

class PlayerViewView extends GetView {
  final HomeController hHomeController;
  PlayerViewView(this.hHomeController, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/placeholder.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Stack(alignment: Alignment.center, children: [
            InkWell(
              onTap: () {
                hHomeController.startPlay();
              },
              child: Container(
                width: context.width * 0.6,
                height: context.width * 0.6,
                decoration: BoxDecoration(
                    color: Color(0xffDA2629),
                    border: Border.all(
                      color: Color(0xffDA2629),
                    ),
                    borderRadius: BorderRadius.all(
                        Radius.circular(context.height * 0.20))),
              ),
            ),
            ObxValue(
                (pp) => pp.value
                    ? SizedBox(
                        width: context.width * 0.56,
                        height: context.width * 0.56,
                        child: CircularProgressIndicator(
                          backgroundColor: Colors.white,
                          valueColor:
                              new AlwaysStoppedAnimation<Color>(Colors.red),
                        ),
                      )
                    : Stack(),
                this.hHomeController.isLoaded),
            ObxValue(
                (pp) => pp.value
                    ? InkWell(
                        onTap: () {
                          hHomeController.startPlay();
                        },
                        child: Icon(
                            const IconData(0xe47c, fontFamily: 'MaterialIcons'),
                            size: 70.h,
                            color: Colors.white),
                      )
                    : InkWell(
                        onTap: () {
                          hHomeController.startPlay();
                        },
                        child: Icon(Icons.play_arrow,
                            size: 70.h, color: Colors.white)),
                this.hHomeController.isPlay)
          ]),
        ),
      ),
    );
  }
}
