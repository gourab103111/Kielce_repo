import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:get/get.dart';
import 'package:leftsideslider/app/routes/app_pages.dart';

import '../controllers/home_controller.dart';
import 'custom_web_page_view.view.dart';
import 'helper/items_lists.dart';
import 'player_view.view.dart';

class HomeView extends GetView<HomeController> {
  HomeView({Key? key}) : super(key: key);

  int _selectedIndex = 0;
  static const TextStyle optionStyle =
      TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static const List<Widget> _widgetOptions = <Widget>[
    Text(
      'Index 0: Home',
      style: optionStyle,
    ),
    Text(
      'Index 1: Business',
      style: optionStyle,
    ),
    Text(
      'Index 2: School',
      style: optionStyle,
    ),
  ];

  void _onItemTapped(int index) {
    switch (index) {
      case 0:
        // this.controller.setPresentView(CustomWebPageViewView());

        this.controller.updateview.value = "CustomWebPageViewView";
        break;
      case 1:
        // this.controller.setPresentView(PlayerViewView());
        this.controller.updateview.value = "PlayerViewView";
        break;
      default:
        // this.controller.setPresentView(CustomWebPageViewView());
        this.controller.updateview.value = "CustomWebPageViewView";
        break;
    }
    // setState(() {
    //   _selectedIndex = index;
    // });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xffDA2629),
        title: null,
        centerTitle: true,
      ),
      body: Container(
          width: context.width,
          height: context.height,
          child: ObxValue(
              (p0) => p0 == "CustomWebPageViewView"
                  ? CustomWebPageViewView()
                  : PlayerViewView(this.controller),
              this.controller.updateview)),
      drawer: Drawer(
        backgroundColor: Color(0xff1F1F1F),
        // Add a ListView to the drawer. This ensures the user can scroll
        // through the options in the drawer if there isn't enough vertical
        // space to fit everything.
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,

          children: [
            DrawerHeader(
              child: Container(
                  alignment: Alignment.center,
                  child: Image.asset("assets/logo.png")),
            ),
            ListsItems('MIASTO', "https://emkielce.pl/miasto"),
            ListsItems('REGION', "https://emkielce.pl/region"),
            ListsItems('KOŚCIÓŁ', "https://emkielce.pl/kosciol"),
            ListsItems('SPORT', "https://emkielce.pl/sport"),
            ListsItems('BIZNES', "https://emkielce.pl/biznes"),
            ListsItems('GALERIA', "https://emkielce.pl/galeria"),
            ListsItems('KULTURA', "https://emkielce.pl/kultura"),
            ListsItems('TYGODNIK', "https://emkielce.pl/tygodnik-m"),
            ListsItems('WIDEO', "https://emkielce.pl/wideo"),
            ListsItems('TWÓJ NEWS', "https://emkielce.pl/twoj-news"),
            ListsItems('REKLAMA', "https://emkielce.pl/reklama"),
            ListsItems('KONTAKT', "https://emkielce.pl/kontakt"),
          ],
        ),
      ),
    );
  }
}
