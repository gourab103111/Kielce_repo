package com.example.leftsideslider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
