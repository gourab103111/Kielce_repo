import 'package:get/get.dart';

class CoustomWebViewController extends GetxController {
  //TODO: Implement CoustomWebViewController

  final count = 0.obs;
  final isLoading = true.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() => count.value++;
}
