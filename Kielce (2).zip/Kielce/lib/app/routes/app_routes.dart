part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const HOME = _Paths.HOME;
  static const COUSTOM_WEB_VIEW = _Paths.HOME + _Paths.COUSTOM_WEB_VIEW;
}

abstract class _Paths {
  _Paths._();
  static const HOME = '/home';
  static const COUSTOM_WEB_VIEW = '/coustom-web-view';
}
